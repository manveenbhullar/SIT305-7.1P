package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.util.Arrays;
import java.util.List;

public class Add extends AppCompatActivity {

    private RadioGroup radio;
    String radiotype;
    TextView text;
    EditText title, desc, phone, date, location;
    Button save;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_advert);

        text = findViewById(R.id.text1);
        title = findViewById(R.id.title1);
        desc = findViewById(R.id.desc);
        phone = findViewById(R.id.phone);
        date = findViewById(R.id.date);
        location = findViewById(R.id.location);
        save = findViewById(R.id.save);
        radio = (RadioGroup) findViewById(R.id.types);
        radio.clearCheck();


        radio.setOnCheckedChangeListener(
                new RadioGroup
                        .OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group,
                                                 int checkedId) {
                        RadioButton
                                radioButton
                                = (RadioButton) group
                                .findViewById(checkedId);
                        radiotype = radioButton.getText().toString();
                    }
                });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(title.getText().toString()) && !TextUtils.isEmpty(desc.getText().toString()) && !TextUtils.isEmpty(phone.getText().toString()) && !TextUtils.isEmpty(date.getText().toString()) && !TextUtils.isEmpty(location.getText().toString())) {
                    Database db = new Database(Add.this);
                    db.add((radiotype + " " + title.getText().toString()), phone.getText().toString(), desc.getText().toString(), date.getText().toString(), location.getText().toString());
                    Intent intent = new Intent(Add.this, MainActivity2.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(Add.this, "Fields are Empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}